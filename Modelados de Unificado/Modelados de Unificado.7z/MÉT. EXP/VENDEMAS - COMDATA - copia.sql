
select *
from gdc..tbl_vendemas_CP_inicial


-- 1. crear periodo

declare @Mes bigint
set @Mes = (select MAX(MONTH(Fecha)) from gdc..tbl_vendemas_CP_inicial)


drop table #tab1
select a.*,
       MONTH(Fecha) as Mes,
	   YEAR(Fecha) as A�o
into #tab1
from gdc..tbl_vendemas_CP_inicial as a
where MONTH(FECHA) = @Mes


drop table #tab2
select a.*,
       case when cast(Mes as float) <= 9 then cast(A�o as varchar) + '0' + cast(Mes as varchar)
	   else cast(A�o as varchar) + cast(Mes as varchar)
	   end as Periodo
into #tab2
from #tab1 as a

-- 2. Cruzar con UN, Segmento, Cluster, GV

alter table #tab2
add unidadnegocio varchar(50)

update #tab2
set unidadnegocio = 'Masivo'
where unidadnegocio is null

alter table #tab2
add segmento varchar(50)

update #tab2
set segmento = 'Masivo'
where segmento is null

alter table #tab2
add cluster varchar(50)

update #tab2
set cluster = 'Sin Cluster'
where cluster is null

alter table #tab2
add Grupo_Valor_F varchar(50)


-- 3. Insertar en tabla final

-- select * from #tab2

insert into gdc..tbl_vendemas_CP_final
select *
from #tab2
