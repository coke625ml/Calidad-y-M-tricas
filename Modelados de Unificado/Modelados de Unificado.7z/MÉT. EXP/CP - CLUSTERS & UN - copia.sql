
select *
from gdc..tbl_MET_EXP_final

use [Visanet Planeamiento]

declare @periodo1 bigint
set @periodo1 = 202208  -- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! COLOCAR PERIODO

--delete from gdc..tbl_MET_EXP_final
--where periodo = 202207

--select top 1 * from gdc..tbl_CP_COMDATA_final
--select top 1 * from gdc..ncp_encu_unif
--select top 1 * from gdc..tbl_CP_SISCARD_final


-- select distinct programa from gdc..tbl_CP_COMDATA_final
-- proveedor:
	-- COMDATA
-- programas:
	-- Afiliaciones -> AFILIACIONES-CALL
	-- Empresas -> EXCLUSIVO-CALL
	-- Masivo -> EXCLUSIVO-CALL
	-- Corporativo -> CORPORATIVO-CALL
	-- C2C Corporativo -> C2C CORPORATIVO-CALL
	-- C2C Vendemas -> C2C VENDEMAS-CALL
	-- 


-- select top 1 * from gdc..tbl_CP_SISCARD_final
-- proveedor:
	-- SISCARD
-- programas:
	-- No tiene programa
	-- Pero, al consolidar TODO debe guardarse como: CALL TECNICO SISCARD


-- select distinct cast(CAMPA�A as varchar) as Campa�a, cast(Campa�aN as varchar) Campa�aNfrom from gdc..ncp_encu_unif
-- proveedor:
	-- NECOMPLUS
-- programa -> Campa�aN:
	-- POS Fisico -> POS FISICO
	-- Partner de Red -> PDR
	-- Pool Online Virtual -> CALL TECNICO NCP




-- 1. Modelado de COMDATA


drop table #tab_COMDATA_CP
select Periodo, unidadnegocio, segmento, clustergrupo, Grupo_Valor_F, Respuesta1 as NPS, Respuesta2 as SAT, Respuesta3 as SOL, Respuesta4 as CES,
	   RUC_F as RUC,
       case when Programa = 'Afiliaciones' then 'AFILIACIONES-CALL'
	        when Programa = 'Empresas' then 'EXCLUSIVO-CALL'
			when Programa = 'Masivo' then 'EXCLUSIVO-CALL'
			when Programa = 'Exclusivo' then 'EXCLUSIVO-CALL'
			when Programa = 'Corporativo' then 'CORPORATIVO-CALL'
			when Programa = 'C2C Corporativo' then 'C2C CORPORATIVO-CALL'
			when Programa = 'C2C Vendemas' then 'C2C VENDEMAS-CALL'
	   else 'Programa_No_ID'
	   end as Gestion_Final

into #tab_COMDATA_CP
from gdc..tbl_CP_COMDATA_final
where unidadnegocio is not null
and periodo = @periodo1

-- AGREGAR PROVEEDOR

alter table #tab_COMDATA_CP
add Proveedor varchar(50)

update #tab_COMDATA_CP
set Proveedor = 'COMDATA'
where Proveedor is null




-- 2. Modelado de NECOMPLUS

-- select * from gdc..ncp_encu_unif


drop table #tab_ID
select distinct Periodo, trasaction
into #tab_ID
from gdc..ncp_encu_unif
where periodo = @periodo1
and tipo_encuesta = 'encuesta completa'


drop table #tab_nps
select trasaction, VALUE_SURVEY
into #tab_nps
from gdc..ncp_encu_unif
where periodo = @periodo1
and tipo_encuesta = 'encuesta completa'
and RUTA_LOCUCION like '%NPS%'

drop table #tab_sat
select trasaction, VALUE_SURVEY
into #tab_sat
from gdc..ncp_encu_unif
where periodo = @periodo1
and tipo_encuesta = 'encuesta completa'
and RUTA_LOCUCION like '%SAT%'


drop table #tab_sol
select trasaction, VALUE_SURVEY
into #tab_sol
from gdc..ncp_encu_unif
where periodo = @periodo1
and tipo_encuesta = 'encuesta completa'
and RUTA_LOCUCION like '%sol%'


drop table #tab_ces
select trasaction, VALUE_SURVEY
into #tab_ces
from gdc..ncp_encu_unif
where periodo = @periodo1
and tipo_encuesta = 'encuesta completa'
and RUTA_LOCUCION like '%ces%'


drop table #tbl_NCP_CP_1
select a.*, b.VALUE_SURVEY as NPS,
       d.VALUE_SURVEY as SAT,
	   e.VALUE_SURVEY as SOL,
	   r.VALUE_SURVEY as CES
intO #tbl_NCP_CP_1
from #tab_ID as a
left join #tab_nps as b on a.TRASACTION = b.TRASACTION
left join #tab_sat as d on a.TRASACTION = d.TRASACTION
left join #tab_sol as e on a.TRASACTION = e.TRASACTION
left join #tab_ces as r on a.TRASACTION = r.TRASACTION



drop table #tbl_NCP_CP_2
select a.*, b.NRUC, UN as unidadnegocio, Segmento, Cluster as clustergrupo
into #tbl_NCP_CP_2
from #tbl_NCP_CP_1 as a
left join gdc..ncp_llamadas_unif as b on a.TRASACTION = b.Id_Transacci�n


drop table #tbl_NCP_CP_3
select a.*, ROW_NUMBER() over (partition by TRASACTION order by Periodo) orden_1
into #tbl_NCP_CP_3
from gdc..ncp_encu_unif as a
where periodo = @periodo1
and tipo_encuesta = 'encuesta completa'


delete from #tbl_NCP_CP_3
where orden_1 > 1


drop table #tbl_NCP_CP_4
select a.*, Grupo_Valor, CAMPA�A
into #tbl_NCP_CP_4
from #tbl_NCP_CP_2 as a
left join #tbl_NCP_CP_3 as b on a.TRASACTION = b.TRASACTION


drop table #tab_NECOMPLUS_CP
select Periodo, unidadnegocio, Segmento, clustergrupo, Grupo_Valor as Grupo_Valor_F, NPS, SAT, SOL, CES, NRUC as RUC,
       CAMPA�A as Gestion_Final
into #tab_NECOMPLUS_CP
from #tbl_NCP_CP_4





-- AGREGAR PROVEEDOR

alter table #tab_NECOMPLUS_CP
add Proveedor varchar(50)

update #tab_NECOMPLUS_CP
set Proveedor = 'NECOMPLUS'
where Proveedor is null



-- 3. Modelado de SISCARD


drop table #tab_SISCARD_CP
select Periodo, unidadnegocio, Segmento as segmento, ClusterGrupo, Cuadrante_No_Aislado as Grupo_Valor_F,
       NPS, SAT, SOL, CES, RUC

into #tab_SISCARD_CP
from gdc..tbl_CP_SISCARD_final
where unidadnegocio is not null
and periodo = @periodo1


-- AGREGAR GESTION_FINAL

alter table #tab_SISCARD_CP
add Gestion_Final varchar(50)

update #tab_SISCARD_CP
set Gestion_Final = 'CALL TECNICO'
where gestion_final is null


-- AGREGAR PROVEEDOR

alter table #tab_SISCARD_CP
add Proveedor varchar(50)

update #tab_SISCARD_CP
set Proveedor = 'SISCARD'
where Proveedor is null




-- Modelado de WHATSAPP COMDATA

drop table #tab_WHATSAPP_COMDATA_CP
select Periodo, unidadnegocio, Segmento, ClusterGrupo, Grupo_Valor_F, NPS, SAT_1, SOL_1, CES_1, DNI_RUC as RUC, Campa�a as Gestion_Final
into #tab_WHATSAPP_COMDATA_CP
from gdc..tbl_whatsapp_CP_final 
where unidadnegocio is not null
and periodo = @periodo1

alter table #tab_WHATSAPP_COMDATA_CP
add Proveedor varchar(50)

-- AGREGAR PROVEEDOR

update #tab_WHATSAPP_COMDATA_CP
set Proveedor = 'COMDATA'
where Proveedor is null




-- Modelado de VENDEMAS COMDATA

drop table #tab_VENDEMAS_COMDATA_CP_INICIAL
select Periodo, unidadnegocio, segmento, cluster as clustergrupo, Grupo_Valor_F, NPS, SATISFACCI�N as SAT,
       SOLUCI�N as SOL, CES, CAMPA�A as Gestion_Final
into #tab_VENDEMAS_COMDATA_CP_INICIAL
from gdc..tbl_vendemas_CP_final
where unidadnegocio is not null
and periodo = @periodo1

alter table #tab_VENDEMAS_COMDATA_CP_INICIAL
add RUC float

drop table #tab_VENDEMAS_COMDATA_CP
select Periodo, unidadnegocio, segmento, clustergrupo, Grupo_Valor_F, NPS, SAT, SOL, CES, 
       RUC, Gestion_Final
into #tab_VENDEMAS_COMDATA_CP
from #tab_VENDEMAS_COMDATA_CP_INICIAL as a

alter table #tab_VENDEMAS_COMDATA_CP
add Proveedor varchar(50)

update #tab_VENDEMAS_COMDATA_CP
set Proveedor = 'COMDATA'
where Proveedor is null




-- Modelado de CONSOLIDADO DIGITALES (HOTJAR, HOWUKU, SM )



drop table #tab_CONSOLIDADO_DIGITALES_CP_SIN_NEL
select Periodo, unidadnegocio, segmento, clustergrupo, Grupo_Valor_F, NPS, SAT, SOL, CES, RUC, Campa�a as Gestion_Final, Proveedor
into #tab_CONSOLIDADO_DIGITALES_CP_SIN_NEL
from gdc..tbl_CONSOLIDADO_DIGITALES_CP_final 
where unidadnegocio is not null
and campa�a <> 'NEL'
and periodo = @periodo1

drop table #tab_CONSOLIDADO_DIGITALES_CP_CON_NEL
select Periodo, unidadnegocio, segmento, clustergrupo, Grupo_Valor_F, NPS, SAT, SOL, CES, RUC, Campa�a as Gestion_Final, Proveedor
into #tab_CONSOLIDADO_DIGITALES_CP_CON_NEL
from gdc..tbl_CONSOLIDADO_DIGITALES_CP_final 
where campa�a = 'NEL'
and periodo = @periodo1


drop table #tab_CONSOLIDADO_DIGITALES_CP
select *
into #tab_CONSOLIDADO_DIGITALES_CP
from
(
select * from #tab_CONSOLIDADO_DIGITALES_CP_SIN_NEL

union all

select * from #tab_CONSOLIDADO_DIGITALES_CP_CON_NEL
) as subquery 


-- Consolidar COMDATA, NECOMPLUS, SISCARD, HOTJAR, HOWUKU, SM


drop table #tab_CONSOLIDAD_PROVEEDORES_CP
select *
into #tab_CONSOLIDAD_PROVEEDORES_CP
from (

select * from #tab_COMDATA_CP

union all 

select * from #tab_NECOMPLUS_CP

union all

select * from #tab_SISCARD_CP

union all 

select * from #tab_WHATSAPP_COMDATA_CP

union all

select * from #tab_VENDEMAS_COMDATA_CP

union all

select * from #tab_CONSOLIDADO_DIGITALES_CP

) as subquery 




-- Calibrar el NPS y crear marcas de NPS



update #tab_CONSOLIDAD_PROVEEDORES_CP
set NPS = 0
where cast(NPS as float) < 0


drop table #tab_CONSOLIDAD_PROVEEDORES_CP_F
select a.*, cast(Gestion_Final as varchar) as Gestion_Final_1
into #tab_CONSOLIDAD_PROVEEDORES_CP_F
from #tab_CONSOLIDAD_PROVEEDORES_CP as a



--select distinct NPS
--from ##tab_CONSOLIDAD_PROVEEDORES_CP_F 
--where proveedor not in ('COMDATA', 'SICARD', 'NECOMPLUS') 
--order by NPS desc


select * from #tab_CONSOLIDAD_PROVEEDORES_CP_F

drop table #tab_FLAG_NPS_1
select a.*,
       case when cast(NPS as float) in (9,8) then 'Promotores'
	        when cast(NPS as float) in (7,6) then 'Neutros'
			when cast(NPS as float) in (5,4,3,2,1,0) then 'Detractores'
			when NPS is null then 'Sin Respuesta'
			else 'Sin Respuesta'
	   end as FLAG_NPS
into #tab_FLAG_NPS_1
from #tab_CONSOLIDAD_PROVEEDORES_CP_F as a
where proveedor in ('COMDATA', 'SISCARD', 'NECOMPLUS') 
and Gestion_Final_1 not in ('WHATSAPP-CALL')
-- order by NPS desc


drop table #tab_FLAG_NPS_2
select a.*,
       case when cast(NPS as float) in (10,9) then 'Promotores'
	        when cast(NPS as float) in (8,7) then 'Neutros'
			when cast(NPS as float) in (6,5,4,3,2,1,0) then 'Detractores'
			when NPS is null then 'Sin Respuesta'
			else 'Sin Respuesta'
	   end as FLAG_NPS
into #tab_FLAG_NPS_2
from #tab_CONSOLIDAD_PROVEEDORES_CP_F as a
where proveedor in ('COMDATA', 'SISCARD', 'NECOMPLUS') 
and Gestion_Final_1 in ('WHATSAPP-CALL')
-- order by NPS desc


drop table #tab_FLAG_NPS_3
select a.*,
       case when cast(NPS as float) in (10,9) then 'Promotores'
	        when cast(NPS as float) in (8,7) then 'Neutros'
			when cast(NPS as float) in (6,5,4,3,2,1,0) then 'Detractores'
			when NPS is null then 'Sin Respuesta'
			else 'Sin Respuesta'
	   end as FLAG_NPS
into #tab_FLAG_NPS_3
from #tab_CONSOLIDAD_PROVEEDORES_CP_F as a
where proveedor not in ('COMDATA', 'SISCARD', 'NECOMPLUS') 
order by NPS desc



-- volver a consolidar la tabla pero con la marca de NPS

drop table #tab_CONSOLIDAD_PROVEEDORES_CP_1
select *
into #tab_CONSOLIDAD_PROVEEDORES_CP_1
from (

select * from #tab_FLAG_NPS_1

union all

select * from #tab_FLAG_NPS_2

union all

select * from #tab_FLAG_NPS_3

) as subquery

	
	-- Validacion de Q:
		--select count (*) from #tab_CONSOLIDAD_PROVEEDORES_CP
		--select count (*) from #tab_CONSOLIDAD_PROVEEDORES_CP_1
		--select count (*) from #tab_CONSOLIDAD_PROVEEDORES_CP_F



-- quitar clusters nulos por ser Masivos y Procesamiento

update #tab_CONSOLIDAD_PROVEEDORES_CP_1
set clustergrupo = 'Sin Cluster'
where clustergrupo is null
and Gestion_Final_1 <> 'NEL'

update #tab_CONSOLIDAD_PROVEEDORES_CP_1
set clustergrupo = 'Sin Cluster'
where clustergrupo = ''
and Gestion_Final_1 <> 'NEL'

--no deben quedar dentro de la tabla base registros que no tengan UN, fuera de NEL que se necesitan todos los registros para calcular el NPS de NEL

delete from #tab_CONSOLIDAD_PROVEEDORES_CP_1
where unidadnegocio is null
and Gestion_Final_1 <> 'NEL'






-- calcular el NPS de NEL

drop table #tab_NPS_NEL_GLOBAL_1
select a.*,
       case when FLAG_NPS = 'Promotores' then 1
	   else 0
	   end as FLAG_PROMOTORES,
	   case when FLAG_NPS = 'Detractores' then 1
	   else 0
	   end as FLAG_DETRACTORES
into #tab_NPS_NEL_GLOBAL_1
from #tab_CONSOLIDAD_PROVEEDORES_CP_1 as a
where Gestion_Final_1 = 'NEL'



drop table #tab_NPS_NEL_GLOBAL_2
select Periodo, SUM(FLAG_PROMOTORES) as Q_Promotores, SUM(FLAG_DETRACTORES) as Q_Detractores, COUNT(*) as Q_Encuestas
into #tab_NPS_NEL_GLOBAL_2
from #tab_NPS_NEL_GLOBAL_1
group by Periodo


drop table #tab_NPS_NEL_GLOBAL
select a.*, cast(Q_Promotores as float)/cast(Q_Encuestas as float) - cast(Q_Detractores as float)/cast(Q_Encuestas as float) NPS_NEL_GLOBAL
into #tab_NPS_NEL_GLOBAL
from #tab_NPS_NEL_GLOBAL_2 as a


-- select * from #tab_NPS_NEL_GLOBAL











-- NPS UN MASIVO


		--drop table #tab_NPS_MASIVO_1
		--select a.*,
		--	   case when FLAG_NPS = 'Promotores' then 1
		--	   else 0
		--	   end as FLAG_PROMOTORES,
		--	   case when FLAG_NPS = 'Detractores' then 1
		--	   else 0
		--	   end as FLAG_DETRACTORES

		--into #tab_NPS_MASIVO_1
		--from #tab_CONSOLIDAD_PROVEEDORES_CP_1 as a
		--where Gestion_Final_1 <> 'NEL'
		--and unidadnegocio = 'Masivo'



		--drop table #tab_NPS_MASIVO_2
		--select Periodo, SUM(FLAG_PROMOTORES) as Q_Promotores, SUM(FLAG_DETRACTORES) as Q_Detractores, COUNT(*) as Q_Encuestas
		--into #tab_NPS_MASIVO_2
		--from #tab_NPS_MASIVO_1
		--group by Periodo


		--drop table #tab_NPS_UN_MASIVO_3
		--select a.*, cast(Q_Promotores as float)/cast(Q_Encuestas as float) - cast(Q_Detractores as float)/cast(Q_Encuestas as float) NPS_MASIVO
		--into #tab_NPS_UN_MASIVO_3
		--from #tab_NPS_MASIVO_2 as a



		--drop table #tab_NPS_UN_MASIVO_4
		--select a.*, b.NPS_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL
		--into #tab_NPS_UN_MASIVO_4
		--from #tab_NPS_UN_MASIVO_3 as a
		--left join #tab_NPS_NEL_GLOBAL as b on a.Periodo = b.Periodo



		--update #tab_NPS_UN_MASIVO_4
		--set Q_Encuestas_NEL = 30 ------------- PONDERACION
		--where Q_Encuestas_NEL = Q_Encuestas_NEL



		--drop table #tab_NPS_UN_MASIVO
		--select a.*, 
		--	   (cast(NPS_MASIVO as float) * cast(Q_Encuestas as float)
		--	   + 
		--	   cast(NPS_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
		--	   /
		--	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as NPS_MASIVO_FINAL
		--into #tab_NPS_UN_MASIVO
		--from #tab_NPS_UN_MASIVO_4 as a 





		----select * from #tab_NPS_UN_MASIVO
		----select * from gdc..tbl_MET_EXP_final where Periodo = 202205






-- NPS UN PROCESAMIENTO



drop table #tab_NPS_PROCESAMIENTO_1
select a.*,
       case when FLAG_NPS = 'Promotores' then 1
	   else 0
	   end as FLAG_PROMOTORES,
	   case when FLAG_NPS = 'Detractores' then 1
	   else 0
	   end as FLAG_DETRACTORES

into #tab_NPS_PROCESAMIENTO_1
from #tab_CONSOLIDAD_PROVEEDORES_CP_1 as a
where Gestion_Final_1 <> 'NEL'
and unidadnegocio = 'Procesamiento'




drop table #tab_NPS_PROCESAMIENTO_2
select Periodo, SUM(FLAG_PROMOTORES) as Q_Promotores, SUM(FLAG_DETRACTORES) as Q_Detractores, COUNT(*) as Q_Encuestas
into #tab_NPS_PROCESAMIENTO_2
from #tab_NPS_PROCESAMIENTO_1
group by Periodo


-- select * from #tab_NPS_PROCESAMIENTO_2


drop table #tab_NPS_PROCESAMIENTO
select a.*, cast(Q_Promotores as float)/cast(Q_Encuestas as float) - cast(Q_Detractores as float)/cast(Q_Encuestas as float) NPS_PROCESAMIENTO_FINAL
into #tab_NPS_PROCESAMIENTO
from #tab_NPS_PROCESAMIENTO_2 as a


--select * from #tab_NPS_PROCESAMIENTO
--select * from gdc..tbl_MET_EXP_final where Periodo = 202205







-- NPS UN CORPORATIVO



		--drop table #tab_NPS_CORPORATIVO_1
		--select a.*,
		--	   case when FLAG_NPS = 'Promotores' then 1
		--	   else 0
		--	   end as FLAG_PROMOTORES,
		--	   case when FLAG_NPS = 'Detractores' then 1
		--	   else 0
		--	   end as FLAG_DETRACTORES

		--into #tab_NPS_CORPORATIVO_1
		--from #tab_CONSOLIDAD_PROVEEDORES_CP_1 as a
		--where Gestion_Final_1 <> 'NEL'
		--and unidadnegocio = 'Corporativo'






		--drop table #tab_NPS_CORPORATIVO_2
		--select Periodo, SUM(FLAG_PROMOTORES) as Q_Promotores, SUM(FLAG_DETRACTORES) as Q_Detractores, COUNT(*) as Q_Encuestas
		--into #tab_NPS_CORPORATIVO_2
		--from #tab_NPS_CORPORATIVO_1
		--group by Periodo


		--drop table #tab_NPS_CORPORATIVO_3
		--select a.*, cast(Q_Promotores as float)/cast(Q_Encuestas as float) - cast(Q_Detractores as float)/cast(Q_Encuestas as float) NPS_CORPORATIVO
		--into #tab_NPS_CORPORATIVO_3
		--from #tab_NPS_CORPORATIVO_2 as a


		--		--select * from #tab_NPS_CORPORATIVO_3


		--drop table #tab_NPS_CORPORATIVO_4
		--select a.*, b.NPS_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL

		--into #tab_NPS_CORPORATIVO_4
		--from #tab_NPS_CORPORATIVO_3 as a
		--left join #tab_NPS_NEL_GLOBAL as b on a.Periodo = b.Periodo



		--update #tab_NPS_CORPORATIVO_4
		--set Q_Encuestas_NEL = 91 ------------- PONDERACION
		--where Q_Encuestas_NEL = Q_Encuestas_NEL



		--drop table #tab_NPS_CORPORATIVO
		--select a.*, 
		--	   (cast(NPS_CORPORATIVO as float) * cast(Q_Encuestas as float)
		--	   + 
		--	   cast(NPS_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
		--	   /
		--	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as NPS_CORPORATIVO_FINAL
		--into #tab_NPS_CORPORATIVO
		--from #tab_NPS_CORPORATIVO_4 as a 





		----select * from #tab_NPS_CORPORATIVO
		----select * from gdc..tbl_MET_EXP_final where Periodo = 202205








-- -- NPS UN CORPORATIVO > CLUSTER : SERV_EXP




drop table #tab_NPS_CORPORATIVO_SERV_EXP_1
select a.*,
       case when FLAG_NPS = 'Promotores' then 1
	   else 0
	   end as FLAG_PROMOTORES,
	   case when FLAG_NPS = 'Detractores' then 1
	   else 0
	   end as FLAG_DETRACTORES

into #tab_NPS_CORPORATIVO_SERV_EXP_1
from #tab_CONSOLIDAD_PROVEEDORES_CP_1 as a
where Gestion_Final_1 <> 'NEL'
and unidadnegocio = 'Corporativo'
and clustergrupo = 'Servicios de Experiencia'






drop table #tab_NPS_CORPORATIVO_SERV_EXP_2
select Periodo, SUM(FLAG_PROMOTORES) as Q_Promotores, SUM(FLAG_DETRACTORES) as Q_Detractores, COUNT(*) as Q_Encuestas
into #tab_NPS_CORPORATIVO_SERV_EXP_2
from #tab_NPS_CORPORATIVO_SERV_EXP_1
group by Periodo


drop table #tab_NPS_CORPORATIVO_SERV_EXP_3
select a.*, cast(Q_Promotores as float)/cast(Q_Encuestas as float) - cast(Q_Detractores as float)/cast(Q_Encuestas as float) NPS_CORPORATIVO
into #tab_NPS_CORPORATIVO_SERV_EXP_3
from #tab_NPS_CORPORATIVO_SERV_EXP_2 as a


		--select * from #tab_NPS_CORPORATIVO_3


drop table #tab_NPS_CORPORATIVO_SERV_EXP_4
select a.*, b.NPS_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL

into #tab_NPS_CORPORATIVO_SERV_EXP_4
from #tab_NPS_CORPORATIVO_SERV_EXP_3 as a
left join #tab_NPS_NEL_GLOBAL as b on a.Periodo = b.Periodo



update #tab_NPS_CORPORATIVO_SERV_EXP_4
set Q_Encuestas_NEL = 11 ------------- PONDERACION
where Q_Encuestas_NEL = Q_Encuestas_NEL



drop table #tab_NPS_CORPORATIVO_SERV_EXP
select a.*, 
       (cast(NPS_CORPORATIVO as float) * cast(Q_Encuestas as float)
	   + 
	   cast(NPS_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
	   /
	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as NPS_CORPORATIVO_FINAL_SERV_EXP
into #tab_NPS_CORPORATIVO_SERV_EXP
from #tab_NPS_CORPORATIVO_SERV_EXP_4 as a 





--select * from #tab_NPS_CORPORATIVO_SERV_EXP
--select * from gdc..tbl_MET_EXP_final where Periodo = 202206










-- NPS UN CORPORATIVO > CLUSTER : SERV_DIG






drop table #tab_NPS_CORPORATIVO_SERV_DIG_1
select a.*,
       case when FLAG_NPS = 'Promotores' then 1
	   else 0
	   end as FLAG_PROMOTORES,
	   case when FLAG_NPS = 'Detractores' then 1
	   else 0
	   end as FLAG_DETRACTORES

into #tab_NPS_CORPORATIVO_SERV_DIG_1
from #tab_CONSOLIDAD_PROVEEDORES_CP_1 as a
where Gestion_Final_1 <> 'NEL'
and unidadnegocio = 'Corporativo'
and clustergrupo = 'Servicios Digitales'






drop table #tab_NPS_CORPORATIVO_SERV_DIG_2
select Periodo, SUM(FLAG_PROMOTORES) as Q_Promotores, SUM(FLAG_DETRACTORES) as Q_Detractores, COUNT(*) as Q_Encuestas
into #tab_NPS_CORPORATIVO_SERV_DIG_2
from #tab_NPS_CORPORATIVO_SERV_DIG_1
group by Periodo


drop table #tab_NPS_CORPORATIVO_SERV_DIG_3
select a.*, cast(Q_Promotores as float)/cast(Q_Encuestas as float) - cast(Q_Detractores as float)/cast(Q_Encuestas as float) NPS_CORPORATIVO
into #tab_NPS_CORPORATIVO_SERV_DIG_3
from #tab_NPS_CORPORATIVO_SERV_DIG_2 as a


		--select * from #tab_NPS_CORPORATIVO_3


drop table #tab_NPS_CORPORATIVO_SERV_DIG_4
select a.*, b.NPS_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL

into #tab_NPS_CORPORATIVO_SERV_DIG_4
from #tab_NPS_CORPORATIVO_SERV_DIG_3 as a
left join #tab_NPS_NEL_GLOBAL as b on a.Periodo = b.Periodo



update #tab_NPS_CORPORATIVO_SERV_DIG_4
set Q_Encuestas_NEL = 21 ------------- PONDERACION
where Q_Encuestas_NEL = Q_Encuestas_NEL



drop table #tab_NPS_CORPORATIVO_SERV_DIG
select a.*, 
       (cast(NPS_CORPORATIVO as float) * cast(Q_Encuestas as float)
	   + 
	   cast(NPS_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
	   /
	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as NPS_CORPORATIVO_FINAL_SERV_DIG
into #tab_NPS_CORPORATIVO_SERV_DIG
from #tab_NPS_CORPORATIVO_SERV_DIG_4 as a 





--select * from #tab_NPS_CORPORATIVO_SERV_DIG
--select * from gdc..tbl_MET_EXP_final where Periodo = 202206












-- NPS UN CORPORATIVO > CLUSTER : GOB










drop table #tab_NPS_CORPORATIVO_GOB_1
select a.*,
       case when FLAG_NPS = 'Promotores' then 1
	   else 0
	   end as FLAG_PROMOTORES,
	   case when FLAG_NPS = 'Detractores' then 1
	   else 0
	   end as FLAG_DETRACTORES

into #tab_NPS_CORPORATIVO_GOB_1
from #tab_CONSOLIDAD_PROVEEDORES_CP_1 as a
where Gestion_Final_1 <> 'NEL'
and unidadnegocio = 'Corporativo'
and clustergrupo = 'Gobierno y Giros en Desarrollo'






drop table #tab_NPS_CORPORATIVO_GOB_2
select Periodo, SUM(FLAG_PROMOTORES) as Q_Promotores, SUM(FLAG_DETRACTORES) as Q_Detractores, COUNT(*) as Q_Encuestas
into #tab_NPS_CORPORATIVO_GOB_2
from #tab_NPS_CORPORATIVO_GOB_1
group by Periodo


drop table #tab_NPS_CORPORATIVO_GOB_3
select a.*, cast(Q_Promotores as float)/cast(Q_Encuestas as float) - cast(Q_Detractores as float)/cast(Q_Encuestas as float) NPS_CORPORATIVO
into #tab_NPS_CORPORATIVO_GOB_3
from #tab_NPS_CORPORATIVO_GOB_2 as a


		--select * from #tab_NPS_CORPORATIVO_3


drop table #tab_NPS_CORPORATIVO_GOB_4
select a.*, b.NPS_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL

into #tab_NPS_CORPORATIVO_GOB_4
from #tab_NPS_CORPORATIVO_GOB_3 as a
left join #tab_NPS_NEL_GLOBAL as b on a.Periodo = b.Periodo



update #tab_NPS_CORPORATIVO_GOB_4
set Q_Encuestas_NEL = 23 ------------- PONDERACION
where Q_Encuestas_NEL = Q_Encuestas_NEL



drop table #tab_NPS_CORPORATIVO_GOB
select a.*, 
       (cast(NPS_CORPORATIVO as float) * cast(Q_Encuestas as float)
	   + 
	   cast(NPS_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
	   /
	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as NPS_CORPORATIVO_FINAL_GOB
into #tab_NPS_CORPORATIVO_GOB
from #tab_NPS_CORPORATIVO_GOB_4 as a 





--select * from #tab_NPS_CORPORATIVO_GOB
--select * from gdc..tbl_MET_EXP_final where Periodo = 202206












-- NPS UN CORPORATIVO > CLUSTER : RET_AMP








	drop table #tab_NPS_CORPORATIVO_RET_AMP_1
	select a.*,
		   case when FLAG_NPS = 'Promotores' then 1
		   else 0
		   end as FLAG_PROMOTORES,
		   case when FLAG_NPS = 'Detractores' then 1
		   else 0
		   end as FLAG_DETRACTORES

	into #tab_NPS_CORPORATIVO_RET_AMP_1
	from #tab_CONSOLIDAD_PROVEEDORES_CP_1 as a
	where Gestion_Final_1 <> 'NEL'
	and unidadnegocio = 'Corporativo'
	and clustergrupo = 'Retail Ampliado'






	drop table #tab_NPS_CORPORATIVO_RET_AMP_2
	select Periodo, SUM(FLAG_PROMOTORES) as Q_Promotores, SUM(FLAG_DETRACTORES) as Q_Detractores, COUNT(*) as Q_Encuestas
	into #tab_NPS_CORPORATIVO_RET_AMP_2
	from #tab_NPS_CORPORATIVO_RET_AMP_1
	group by Periodo


	drop table #tab_NPS_CORPORATIVO_RET_AMP_3
	select a.*, cast(Q_Promotores as float)/cast(Q_Encuestas as float) - cast(Q_Detractores as float)/cast(Q_Encuestas as float) NPS_CORPORATIVO
	into #tab_NPS_CORPORATIVO_RET_AMP_3
	from #tab_NPS_CORPORATIVO_RET_AMP_2 as a


			--select * from #tab_NPS_CORPORATIVO_3


	drop table #tab_NPS_CORPORATIVO_RET_AMP_4
	select a.*, b.NPS_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL

	into #tab_NPS_CORPORATIVO_RET_AMP_4
	from #tab_NPS_CORPORATIVO_RET_AMP_3 as a
	left join #tab_NPS_NEL_GLOBAL as b on a.Periodo = b.Periodo



	update #tab_NPS_CORPORATIVO_RET_AMP_4
	set Q_Encuestas_NEL = 36 ------------- PONDERACION
	where Q_Encuestas_NEL = Q_Encuestas_NEL



	drop table #tab_NPS_CORPORATIVO_RET_AMP
	select a.*, 
		   (cast(NPS_CORPORATIVO as float) * cast(Q_Encuestas as float)
		   + 
		   cast(NPS_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
		   /
		   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as NPS_CORPORATIVO_FINAL_RET_AMP
	into #tab_NPS_CORPORATIVO_RET_AMP
	from #tab_NPS_CORPORATIVO_RET_AMP_4 as a 





--select * from #tab_NPS_CORPORATIVO_RET_AMP
--select * from gdc..tbl_MET_EXP_final where Periodo = 202206










-- SOL POR UN & CLUSTER




-- SOL PROCESAMIENTO


drop table #tab_SOL_PROCESAMIENTO_1
select Periodo, SUM(CAST(SOL as float)) as Q_Sol, COUNT(*) as Q_Encuestas
into #tab_SOL_PROCESAMIENTO_1
from #tab_CONSOLIDAD_PROVEEDORES_CP_1
where unidadnegocio = 'Procesamiento'
and Gestion_Final_1 <> 'NEL'
and SOL is not null
group by Periodo



drop table #tab_SOL_PROCESAMIENTO
select a.*, cast(Q_Sol as float)/cast(Q_Encuestas as float) SOL_PROCESAMIENTO
into #tab_SOL_PROCESAMIENTO
from #tab_SOL_PROCESAMIENTO_1 as a

 --select * from #tab_SOL_PROCESAMIENTO
 --select * from gdc..tbl_MET_EXP_final where Periodo = 202206








-- SOL NEL






drop table #tab_SOL_NEL_GLOBAL_1
select Periodo, SUM(CAST(SOL as float)) as Q_Sol, COUNT(*) as Q_Encuestas
into #tab_SOL_NEL_GLOBAL_1
from #tab_CONSOLIDAD_PROVEEDORES_CP_1
where Gestion_Final_1 = 'NEL'
and SOL is not null
group by Periodo


-- select * from #tab_SOL_NEL_GLOBAL_1


drop table #tab_SOL_NEL_GLOBAL
select a.*, cast(Q_Sol as float)/cast(Q_Encuestas as float) SOL_NEL_GLOBAL
into #tab_SOL_NEL_GLOBAL
from #tab_SOL_NEL_GLOBAL_1 as a


 --select * from #tab_SOL_NEL_GLOBAL
 --select * from gdc..tbl_MET_EXP_final where Periodo = 202206




 

 
 -- SOL UN > CLUSTER SER_EXP





drop table #tab_SOL_CORORATIVO_SERV_EXP_3
select Periodo, SUM(CAST(SOL as float)) as Q_Sol, COUNT(*) as Q_Encuestas
into #tab_SOL_CORORATIVO_SERV_EXP_3
from #tab_CONSOLIDAD_PROVEEDORES_CP_1
where unidadnegocio = 'Corporativo'
and Gestion_Final_1 <> 'NEL'
and clustergrupo = 'Servicios de Experiencia'
and SOL is not null
group by Periodo




drop table #tab_SOL_CORORATIVO_SERV_EXP_2
select a.*, cast(Q_Sol as float)/cast(Q_Encuestas as float) SOL_CORPORATIVO_SERV_EXP
into #tab_SOL_CORORATIVO_SERV_EXP_2
from #tab_SOL_CORORATIVO_SERV_EXP_3 as a




drop table #tab_SOL_CORORATIVO_SERV_EXP_1
select a.*, b.SOL_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL
into #tab_SOL_CORORATIVO_SERV_EXP_1
from #tab_SOL_CORORATIVO_SERV_EXP_2 as a
left join #tab_SOL_NEL_GLOBAL as b on a.Periodo = b.Periodo



update #tab_SOL_CORORATIVO_SERV_EXP_1
set Q_Encuestas_NEL = 11
where Q_Encuestas_NEL = Q_Encuestas_NEL




drop table #tab_SOL_CORORATIVO_SERV_EXP
select a.*,
		(cast(SOL_CORPORATIVO_SERV_EXP as float) * cast(Q_Encuestas as float)
	   + 
	   cast(SOL_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
	   /
	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as SOL_CORPORATIVO_FINAL_SERV_EXP
into #tab_SOL_CORORATIVO_SERV_EXP
from #tab_SOL_CORORATIVO_SERV_EXP_1 as a




-- select * from #tab_SOL_CORORATIVO_SERV_EXP
--select * from gdc..tbl_MET_EXP_final where Periodo = 202206









 -- SOL UN > CLUSTER SER_EXP





drop table #tab_SOL_CORORATIVO_SERV_DIG_3
select Periodo, SUM(CAST(SOL as float)) as Q_Sol, COUNT(*) as Q_Encuestas
into #tab_SOL_CORORATIVO_SERV_DIG_3
from #tab_CONSOLIDAD_PROVEEDORES_CP_1
where unidadnegocio = 'Corporativo'
and Gestion_Final_1 <> 'NEL'
and clustergrupo = 'Servicios Digitales'
and SOL is not null
group by Periodo




drop table #tab_SOL_CORORATIVO_SERV_DIG_2
select a.*, cast(Q_Sol as float)/cast(Q_Encuestas as float) SOL_CORPORATIVO_SERV_DIG
into #tab_SOL_CORORATIVO_SERV_DIG_2
from #tab_SOL_CORORATIVO_SERV_DIG_3 as a




drop table #tab_SOL_CORORATIVO_SERV_DIG_1
select a.*, b.SOL_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL
into #tab_SOL_CORORATIVO_SERV_DIG_1
from #tab_SOL_CORORATIVO_SERV_DIG_2 as a
left join #tab_SOL_NEL_GLOBAL as b on a.Periodo = b.Periodo



update #tab_SOL_CORORATIVO_SERV_DIG_1
set Q_Encuestas_NEL = 21
where Q_Encuestas_NEL = Q_Encuestas_NEL




drop table #tab_SOL_CORORATIVO_SERV_DIG
select a.*,
		(cast(SOL_CORPORATIVO_SERV_DIG as float) * cast(Q_Encuestas as float)
	   + 
	   cast(SOL_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
	   /
	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as SOL_CORPORATIVO_FINAL_SERV_DIG
into #tab_SOL_CORORATIVO_SERV_DIG
from #tab_SOL_CORORATIVO_SERV_DIG_1 as a




 --select * from #tab_SOL_CORORATIVO_SERV_DIG
 --select * from gdc..tbl_MET_EXP_final where Periodo = 202206












 -- SOL UN > CLUSTER GOB





drop table #tab_SOL_CORORATIVO_GOB_3
select Periodo, SUM(CAST(SOL as float)) as Q_Sol, COUNT(*) as Q_Encuestas
into #tab_SOL_CORORATIVO_GOB_3
from #tab_CONSOLIDAD_PROVEEDORES_CP_1
where unidadnegocio = 'Corporativo'
and Gestion_Final_1 <> 'NEL'
and clustergrupo = 'Gobierno y Giros en Desarrollo'
and SOL is not null
group by Periodo




drop table #tab_SOL_CORORATIVO_GOB_2
select a.*, cast(Q_Sol as float)/cast(Q_Encuestas as float) SOL_CORPORATIVO_GOB
into #tab_SOL_CORORATIVO_GOB_2
from #tab_SOL_CORORATIVO_GOB_3 as a




drop table #tab_SOL_CORORATIVO_GOB_1
select a.*, b.SOL_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL
into #tab_SOL_CORORATIVO_GOB_1
from #tab_SOL_CORORATIVO_GOB_2 as a
left join #tab_SOL_NEL_GLOBAL as b on a.Periodo = b.Periodo



update #tab_SOL_CORORATIVO_GOB_1
set Q_Encuestas_NEL = 23
where Q_Encuestas_NEL = Q_Encuestas_NEL




drop table #tab_SOL_CORORATIVO_GOB
select a.*,
		(cast(SOL_CORPORATIVO_GOB as float) * cast(Q_Encuestas as float)
	   + 
	   cast(SOL_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
	   /
	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as SOL_CORPORATIVO_FINAL_GOB
into #tab_SOL_CORORATIVO_GOB
from #tab_SOL_CORORATIVO_GOB_1 as a




 --select * from #tab_SOL_CORORATIVO_GOB
 --select * from gdc..tbl_MET_EXP_final where Periodo = 202206











 -- SOL UN > CLUSTER GOB
 




drop table #tab_SOL_CORORATIVO_RET_AMP_3
select Periodo, SUM(CAST(SOL as float)) as Q_Sol, COUNT(*) as Q_Encuestas
into #tab_SOL_CORORATIVO_RET_AMP_3
from #tab_CONSOLIDAD_PROVEEDORES_CP_1
where unidadnegocio = 'Corporativo'
and Gestion_Final_1 <> 'NEL'
and clustergrupo = 'Retail Ampliado'
and SOL is not null
group by Periodo




drop table #tab_SOL_CORORATIVO_RET_AMP_2
select a.*, cast(Q_Sol as float)/cast(Q_Encuestas as float) SOL_CORPORATIVO_RET_AMP
into #tab_SOL_CORORATIVO_RET_AMP_2
from #tab_SOL_CORORATIVO_RET_AMP_3 as a




drop table #tab_SOL_CORORATIVO_RET_AMP_1
select a.*, b.SOL_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL
into #tab_SOL_CORORATIVO_RET_AMP_1
from #tab_SOL_CORORATIVO_RET_AMP_2 as a
left join #tab_SOL_NEL_GLOBAL as b on a.Periodo = b.Periodo



update #tab_SOL_CORORATIVO_RET_AMP_1
set Q_Encuestas_NEL = 36
where Q_Encuestas_NEL = Q_Encuestas_NEL




drop table #tab_SOL_CORORATIVO_RET_AMP
select a.*,
		(cast(SOL_CORPORATIVO_RET_AMP as float) * cast(Q_Encuestas as float)
	   + 
	   cast(SOL_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
	   /
	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as SOL_CORPORATIVO_FINAL_RET_AMP
into #tab_SOL_CORORATIVO_RET_AMP
from #tab_SOL_CORORATIVO_RET_AMP_1 as a




 --select * from #tab_SOL_CORORATIVO_RET_AMP
 --select * from gdc..tbl_MET_EXP_final where Periodo = 202206


















-- CES








-- creacion de tabla con FLAG_CES


drop table #tab_CONSOLIDAD_PROVEEDORES_CP_2
select a.*,
       case when cast(CES as float) = '5' or cast(CES as float) = 4 then '1'
	   else '0'
	   end as FLAG_CES 
into #tab_CONSOLIDAD_PROVEEDORES_CP_2
from #tab_CONSOLIDAD_PROVEEDORES_CP_1 as a



delete from #tab_CONSOLIDAD_PROVEEDORES_CP_2
where unidadnegocio is null
and Gestion_Final_1 <> 'NEL'





		--select count (*) as q from #tab_CONSOLIDAD_PROVEEDORES_CP_2 where Gestion_Final_1 = 'NEL'
		--select count (*) as q from #tab_CONSOLIDAD_PROVEEDORES_CP_2 where Gestion_Final_1 = 'NEL' and CES is not null
		--select * from #tab_CONSOLIDAD_PROVEEDORES_CP_2 where Gestion_Final_1 = 'NEL' and CES is not null










-- CES NEL






drop table #tab_CES_NEL_GLOBAL_1
select Periodo, SUM(CAST(FLAG_CES as float)) as Q_Sat_Muy_Sat, COUNT(*) as Q_Encuestas
into #tab_CES_NEL_GLOBAL_1
from #tab_CONSOLIDAD_PROVEEDORES_CP_2
where Gestion_Final_1 = 'NEL'
and CES is not null
group by Periodo

select * from #tab_CES_NEL_GLOBAL_1

drop table #tab_CES_NEL_GLOBAL
select a.*, cast(Q_Sat_Muy_Sat as float)/cast(Q_Encuestas as float) CES_NEL_GLOBAL
into #tab_CES_NEL_GLOBAL
from #tab_CES_NEL_GLOBAL_1 as a


-- select * from #tab_CES_NEL_GLOBAL









-- CES PROCESAMIENTO





drop table #tab_CES_PROCESAMIENTO_1
select Periodo, SUM(CAST(FLAG_CES as float)) as Q_Sat_Muy_Sat, COUNT(*) as Q_Encuestas
into #tab_CES_PROCESAMIENTO_1
from #tab_CONSOLIDAD_PROVEEDORES_CP_2
where unidadnegocio = 'Procesamiento'
and Gestion_Final_1 <> 'NEL'
and CES is not null
group by Periodo

select * from #tab_CES_PROCESAMIENTO_1

drop table #tab_CES_PROCESAMIENTO
select a.*, cast(Q_Sat_Muy_Sat as float)/cast(Q_Encuestas as float) CES_PROCESAMIENTO
into #tab_CES_PROCESAMIENTO
from #tab_CES_PROCESAMIENTO_1 as a


-- select * from #tab_CES_PROCESAMIENTO















-- CES UN > CLUSTER SER_EXP





drop table #tab_CES_CORORATIVO_SERV_EXP_3
select Periodo, SUM(CAST(FLAG_CES as float)) as Q_Sat_Muy_Sat, COUNT(*) as Q_Encuestas
into #tab_CES_CORORATIVO_SERV_EXP_3
from #tab_CONSOLIDAD_PROVEEDORES_CP_2
where unidadnegocio = 'Corporativo'
and Gestion_Final_1 <> 'NEL'
and clustergrupo = 'Servicios de Experiencia'
and CES is not null
group by Periodo




drop table #tab_CES_CORORATIVO_SERV_EXP_2
select a.*, cast(Q_Sat_Muy_Sat as float)/cast(Q_Encuestas as float) CES_CORPORATIVO_SERV_EXP
into #tab_CES_CORORATIVO_SERV_EXP_2
from #tab_CES_CORORATIVO_SERV_EXP_3 as a




drop table #tab_CES_CORORATIVO_SERV_EXP_1
select a.*, b.CES_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL
into #tab_CES_CORORATIVO_SERV_EXP_1
from #tab_CES_CORORATIVO_SERV_EXP_2 as a
left join #tab_CES_NEL_GLOBAL as b on a.Periodo = b.Periodo



update #tab_CES_CORORATIVO_SERV_EXP_1
set Q_Encuestas_NEL = 11
where Q_Encuestas_NEL = Q_Encuestas_NEL




drop table #tab_CES_CORORATIVO_SERV_EXP
select a.*,
		(cast(CES_CORPORATIVO_SERV_EXP as float) * cast(Q_Encuestas as float)
	   + 
	   cast(CES_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
	   /
	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as CES_CORPORATIVO_FINAL_SERV_EXP
into #tab_CES_CORORATIVO_SERV_EXP
from #tab_CES_CORORATIVO_SERV_EXP_1 as a




-- select * from #tab_CES_CORORATIVO_SERV_EXP













-- CES UN > CLUSTER SERV_DIG









drop table #tab_CES_CORORATIVO_SERV_DIG_3
select Periodo, SUM(CAST(FLAG_CES as float)) as Q_Sat_Muy_Sat, COUNT(*) as Q_Encuestas
into #tab_CES_CORORATIVO_SERV_DIG_3
from #tab_CONSOLIDAD_PROVEEDORES_CP_2
where unidadnegocio = 'Corporativo'
and Gestion_Final_1 <> 'NEL'
and clustergrupo = 'Servicios Digitales'
and CES is not null
group by Periodo




drop table #tab_CES_CORORATIVO_SERV_DIG_2
select a.*, cast(Q_Sat_Muy_Sat as float)/cast(Q_Encuestas as float) CES_CORPORATIVO_SERV_DIG
into #tab_CES_CORORATIVO_SERV_DIG_2
from #tab_CES_CORORATIVO_SERV_DIG_3 as a




drop table #tab_CES_CORORATIVO_SERV_DIG_1
select a.*, b.CES_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL
into #tab_CES_CORORATIVO_SERV_DIG_1
from #tab_CES_CORORATIVO_SERV_DIG_2 as a
left join #tab_CES_NEL_GLOBAL as b on a.Periodo = b.Periodo



update #tab_CES_CORORATIVO_SERV_DIG_1
set Q_Encuestas_NEL = 21
where Q_Encuestas_NEL = Q_Encuestas_NEL




drop table #tab_CES_CORORATIVO_SERV_DIG
select a.*,
		(cast(CES_CORPORATIVO_SERV_DIG as float) * cast(Q_Encuestas as float)
	   + 
	   cast(CES_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
	   /
	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as CES_CORPORATIVO_FINAL_SERV_DIG
into #tab_CES_CORORATIVO_SERV_DIG
from #tab_CES_CORORATIVO_SERV_DIG_1 as a


-- select * from #tab_CES_CORORATIVO_SERV_DIG













-- CES UN > CLUSTER GOB








drop table #tab_CES_CORORATIVO_GOB_3
select Periodo, SUM(CAST(FLAG_CES as float)) as Q_Sat_Muy_Sat, COUNT(*) as Q_Encuestas
into #tab_CES_CORORATIVO_GOB_3
from #tab_CONSOLIDAD_PROVEEDORES_CP_2
where unidadnegocio = 'Corporativo'
and Gestion_Final_1 <> 'NEL'
and clustergrupo = 'Gobierno y Giros en Desarrollo'
and CES is not null
group by Periodo




drop table #tab_CES_CORORATIVO_GOB_2
select a.*, cast(Q_Sat_Muy_Sat as float)/cast(Q_Encuestas as float) CES_CORPORATIVO_GOB
into #tab_CES_CORORATIVO_GOB_2
from #tab_CES_CORORATIVO_GOB_3 as a




drop table #tab_CES_CORORATIVO_GOB_1
select a.*, b.CES_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL
into #tab_CES_CORORATIVO_GOB_1
from #tab_CES_CORORATIVO_GOB_2 as a
left join #tab_CES_NEL_GLOBAL as b on a.Periodo = b.Periodo



update #tab_CES_CORORATIVO_GOB_1
set Q_Encuestas_NEL = 23
where Q_Encuestas_NEL = Q_Encuestas_NEL




drop table #tab_CES_CORORATIVO_GOB
select a.*,
		(cast(CES_CORPORATIVO_GOB as float) * cast(Q_Encuestas as float)
	   + 
	   cast(CES_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
	   /
	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as CES_CORPORATIVO_FINAL_GOB
into #tab_CES_CORORATIVO_GOB
from #tab_CES_CORORATIVO_GOB_1 as a


-- select * from #tab_CES_CORORATIVO_GOB














-- CES UN > CLUSTER RET_AMP









drop table #tab_CES_CORORATIVO_RET_AMP_3
select Periodo, SUM(CAST(FLAG_CES as float)) as Q_Sat_Muy_Sat, COUNT(*) as Q_Encuestas
into #tab_CES_CORORATIVO_RET_AMP_3
from #tab_CONSOLIDAD_PROVEEDORES_CP_2
where unidadnegocio = 'Corporativo'
and Gestion_Final_1 <> 'NEL'
and clustergrupo = 'Retail Ampliado'
and CES is not null
group by Periodo




drop table #tab_CES_CORORATIVO_RET_AMP_2
select a.*, cast(Q_Sat_Muy_Sat as float)/cast(Q_Encuestas as float) CES_CORPORATIVO_RET_AMP
into #tab_CES_CORORATIVO_RET_AMP_2
from #tab_CES_CORORATIVO_RET_AMP_3 as a




drop table #tab_CES_CORORATIVO_RET_AMP_1
select a.*, b.CES_NEL_GLOBAL, b.Q_Encuestas as Q_Encuestas_NEL
into #tab_CES_CORORATIVO_RET_AMP_1
from #tab_CES_CORORATIVO_RET_AMP_2 as a
left join #tab_CES_NEL_GLOBAL as b on a.Periodo = b.Periodo



update #tab_CES_CORORATIVO_RET_AMP_1
set Q_Encuestas_NEL = 36
where Q_Encuestas_NEL = Q_Encuestas_NEL




drop table #tab_CES_CORORATIVO_RET_AMP
select a.*,
		(cast(CES_CORPORATIVO_RET_AMP as float) * cast(Q_Encuestas as float)
	   + 
	   cast(CES_NEL_GLOBAL as float) * cast(Q_Encuestas_NEL as float))
	   /
	   (cast(Q_encuestas as float) + cast(Q_Encuestas_NEL as float)) as CES_CORPORATIVO_FINAL_RET_AMP
into #tab_CES_CORORATIVO_RET_AMP
from #tab_CES_CORORATIVO_RET_AMP_1 as a


-- select * from #tab_CES_CORORATIVO_RET_AMP





--select * from #tab_SOL_PROCESAMIENTO
--select * from #tab_SOL_CORORATIVO_SERV_EXP
--select * from #tab_SOL_CORORATIVO_SERV_DIG
--select * from #tab_SOL_CORORATIVO_GOB
--select * from #tab_SOL_CORORATIVO_RET_AMP






--select * from #tab_CES_PROCESAMIENTO
--select * from #tab_CES_CORORATIVO_SERV_EXP
--select * from #tab_CES_CORORATIVO_SERV_DIG
--select * from #tab_CES_CORORATIVO_GOB
--select * from #tab_CES_CORORATIVO_RET_AMP



-- select * from #tab_CONSOLIDAD_PROVEEDORES_CP_2











-- !!!!!!!!!!!!!! CONSOLIDACION NPS FINAL








select * from #tab_NPS_PROCESAMIENTO

alter table #tab_NPS_PROCESAMIENTO
add UN_CLUSTER varchar(50)

update #tab_NPS_PROCESAMIENTO
set UN_CLUSTER = 'UN Procesamiento'
where UN_CLUSTER is null

drop table #tab_NPS_PROCESAMIENTO_FINAL
select Periodo, UN_CLUSTER, NPS_PROCESAMIENTO_FINAL as NPS 
into #tab_NPS_PROCESAMIENTO_FINAL
from #tab_NPS_PROCESAMIENTO

select * from #tab_NPS_PROCESAMIENTO_FINAL






select * from #tab_NPS_CORPORATIVO_SERV_EXP

alter table #tab_NPS_CORPORATIVO_SERV_EXP
add UN_CLUSTER varchar(50)

update #tab_NPS_CORPORATIVO_SERV_EXP
set UN_CLUSTER = 'Cl�ster Servicios de Experiencia'
where UN_CLUSTER is null

drop table #tab_NPS_CORPORATIVO_SERV_EXP_FINAL
select Periodo, UN_CLUSTER, NPS_CORPORATIVO_FINAL_SERV_EXP as NPS
into #tab_NPS_CORPORATIVO_SERV_EXP_FINAL
from #tab_NPS_CORPORATIVO_SERV_EXP

select * from #tab_NPS_CORPORATIVO_SERV_EXP_FINAL





select * from #tab_NPS_CORPORATIVO_SERV_DIG

alter table #tab_NPS_CORPORATIVO_SERV_DIG
add UN_CLUSTER varchar(50)

update #tab_NPS_CORPORATIVO_SERV_DIG
set UN_CLUSTER = 'Cl�ster Servicios Digitales'
where UN_CLUSTER is null

drop table #tab_NPS_CORPORATIVO_SERV_DIG_FINAL
select Periodo, UN_CLUSTER, NPS_CORPORATIVO_FINAL_SERV_DIG as NPS
into #tab_NPS_CORPORATIVO_SERV_DIG_FINAL
from #tab_NPS_CORPORATIVO_SERV_DIG

select * from #tab_NPS_CORPORATIVO_SERV_DIG_FINAL





select * from #tab_NPS_CORPORATIVO_GOB

alter table #tab_NPS_CORPORATIVO_GOB
add UN_CLUSTER varchar(50)

update #tab_NPS_CORPORATIVO_GOB
set UN_CLUSTER = 'Cl�ster GED'
where UN_CLUSTER is null

drop table #tab_NPS_CORPORATIVO_GOB_FINAL
select Periodo, UN_CLUSTER, NPS_CORPORATIVO_FINAL_GOB as NPS
into #tab_NPS_CORPORATIVO_GOB_FINAL
from #tab_NPS_CORPORATIVO_GOB

select * from #tab_NPS_CORPORATIVO_GOB_FINAL





select * from #tab_NPS_CORPORATIVO_RET_AMP

alter table #tab_NPS_CORPORATIVO_RET_AMP
add UN_CLUSTER varchar(50)

update #tab_NPS_CORPORATIVO_RET_AMP
set UN_CLUSTER = 'Cl�ster Retail Ampliado'
where UN_CLUSTER is null

drop table #tab_NPS_CORPORATIVO_RET_AMP_FINAL
select Periodo, UN_CLUSTER, NPS_CORPORATIVO_FINAL_RET_AMP as NPS
into #tab_NPS_CORPORATIVO_RET_AMP_FINAL
from #tab_NPS_CORPORATIVO_RET_AMP

select * from #tab_NPS_CORPORATIVO_RET_AMP_FINAL




drop table #tab_consolidacion_NPS
select *
into #tab_consolidacion_NPS
from (

select * from #tab_NPS_PROCESAMIENTO_FINAL

union all

select * from #tab_NPS_CORPORATIVO_SERV_EXP_FINAL

union all

select * from #tab_NPS_CORPORATIVO_SERV_DIG_FINAL

union all

select * from #tab_NPS_CORPORATIVO_GOB_FINAL

union all

select * from #tab_NPS_CORPORATIVO_RET_AMP_FINAL

) as subquery







-- !!!!!!!!!!!!!! CONSOLIDACION SOL FINAL








select * from #tab_SOL_PROCESAMIENTO

alter table #tab_SOL_PROCESAMIENTO
add UN_CLUSTER varchar(50)

update #tab_SOL_PROCESAMIENTO
set UN_CLUSTER = 'UN Procesamiento'
where UN_CLUSTER is null

drop table #tab_SOL_PROCESAMIENTO_FINAL
select Periodo, UN_CLUSTER, SOL_PROCESAMIENTO as SOL
into #tab_SOL_PROCESAMIENTO_FINAL
from #tab_SOL_PROCESAMIENTO

select * from #tab_SOL_PROCESAMIENTO_FINAL





select * from #tab_SOL_CORORATIVO_SERV_EXP

alter table #tab_SOL_CORORATIVO_SERV_EXP
add UN_CLUSTER varchar(50)

update #tab_SOL_CORORATIVO_SERV_EXP
set UN_CLUSTER = 'Cl�ster Servicios de Experiencia'
where UN_CLUSTER is null

drop table #tab_SOL_CORPORATIVO_SERV_EXP_FINAL
select Periodo, UN_CLUSTER, SOL_CORPORATIVO_FINAL_SERV_EXP as SOL
into #tab_SOL_CORPORATIVO_SERV_EXP_FINAL
from #tab_SOL_CORORATIVO_SERV_EXP

select * from #tab_SOL_CORPORATIVO_SERV_EXP_FINAL





select * from #tab_SOL_CORORATIVO_SERV_DIG

alter table #tab_SOL_CORORATIVO_SERV_DIG
add UN_CLUSTER varchar(50)

update #tab_SOL_CORORATIVO_SERV_DIG
set UN_CLUSTER = 'Cl�ster Servicios Digitales'
where UN_CLUSTER is null

drop table #tab_SOL_CORPORATIVO_SERV_DIG_FINAL
select Periodo, UN_CLUSTER, SOL_CORPORATIVO_FINAL_SERV_DIG as SOL
into #tab_SOL_CORPORATIVO_SERV_DIG_FINAL
from #tab_SOL_CORORATIVO_SERV_DIG

select * from #tab_SOL_CORPORATIVO_SERV_DIG_FINAL





select * from #tab_SOL_CORORATIVO_GOB

alter table #tab_SOL_CORORATIVO_GOB
add UN_CLUSTER varchar(50)

update #tab_SOL_CORORATIVO_GOB
set UN_CLUSTER = 'Cl�ster GED'
where UN_CLUSTER is null

drop table #tab_SOL_CORPORATIVO_GOB_FINAL
select Periodo, UN_CLUSTER, SOL_CORPORATIVO_FINAL_GOB as SOL
into #tab_SOL_CORPORATIVO_GOB_FINAL
from #tab_SOL_CORORATIVO_GOB

select * from #tab_SOL_CORPORATIVO_GOB_FINAL




select * from #tab_SOL_CORORATIVO_RET_AMP

alter table #tab_SOL_CORORATIVO_RET_AMP
add UN_CLUSTER varchar(50)

update #tab_SOL_CORORATIVO_RET_AMP
set UN_CLUSTER = 'Cl�ster Retail Ampliado'
where UN_CLUSTER is null

drop table #tab_SOL_CORPORATIVO_RET_AMP_FINAL
select Periodo, UN_CLUSTER, SOL_CORPORATIVO_FINAL_RET_AMP as SOL
into #tab_SOL_CORPORATIVO_RET_AMP_FINAL
from #tab_SOL_CORORATIVO_RET_AMP

select * from #tab_SOL_CORPORATIVO_RET_AMP_FINAL




drop table #tab_consolidacion_SOL
select *
into #tab_consolidacion_SOL
from (

select * from #tab_SOL_PROCESAMIENTO_FINAL

union all

select * from #tab_SOL_CORPORATIVO_SERV_EXP_FINAL

union all

select * from #tab_SOL_CORPORATIVO_SERV_DIG_FINAL

union all

select * from #tab_SOL_CORPORATIVO_GOB_FINAL

union all

select * from #tab_SOL_CORPORATIVO_RET_AMP_FINAL

) as subquery







-- !!!!!!!!!!!!!! CONSOLIDACION CES FINAL


select * from #tab_CES_PROCESAMIENTO

alter table #tab_CES_PROCESAMIENTO
add UN_CLUSTER varchar(50)

update #tab_CES_PROCESAMIENTO
set UN_CLUSTER = 'UN Procesamiento'
where UN_CLUSTER is null

drop table #tab_CES_PROCESAMIENTO_FINAL
select Periodo, UN_CLUSTER, CES_PROCESAMIENTO as CES 
into #tab_CES_PROCESAMIENTO_FINAL
from #tab_CES_PROCESAMIENTO

select * from #tab_CES_PROCESAMIENTO_FINAL








select * from #tab_CES_CORORATIVO_SERV_EXP

alter table #tab_CES_CORORATIVO_SERV_EXP
add UN_CLUSTER varchar(50)

update #tab_CES_CORORATIVO_SERV_EXP
set UN_CLUSTER = 'Cl�ster Servicios de Experiencia'
where UN_CLUSTER is null

drop table #tab_CES_CORORATIVO_SERV_EXP_FINAL
select Periodo, UN_CLUSTER, CES_CORPORATIVO_FINAL_SERV_EXP as CES 
into #tab_CES_CORORATIVO_SERV_EXP_FINAL
from #tab_CES_CORORATIVO_SERV_EXP

select * from #tab_CES_CORORATIVO_SERV_EXP_FINAL







select * from #tab_CES_CORORATIVO_SERV_DIG

alter table #tab_CES_CORORATIVO_SERV_DIG
add UN_CLUSTER varchar(50)

update #tab_CES_CORORATIVO_SERV_DIG
set UN_CLUSTER = 'Cl�ster Servicios Digitales'
where UN_CLUSTER is null

drop table #tab_CES_CORORATIVO_SERV_DIG_FINAL
select Periodo, UN_CLUSTER, CES_CORPORATIVO_FINAL_SERV_DIG as CES 
into #tab_CES_CORORATIVO_SERV_DIG_FINAL
from #tab_CES_CORORATIVO_SERV_DIG

select * from #tab_CES_CORORATIVO_SERV_DIG_FINAL





select * from #tab_CES_CORORATIVO_GOB

alter table #tab_CES_CORORATIVO_GOB
add UN_CLUSTER varchar(50)

update #tab_CES_CORORATIVO_GOB
set UN_CLUSTER = 'Cl�ster GED'
where UN_CLUSTER is null

drop table #tab_CES_CORORATIVO_GOB_FINAL
select Periodo, UN_CLUSTER, CES_CORPORATIVO_FINAL_GOB as CES 
into #tab_CES_CORORATIVO_GOB_FINAL
from #tab_CES_CORORATIVO_GOB

select * from #tab_CES_CORORATIVO_GOB_FINAL








select * from #tab_CES_CORORATIVO_RET_AMP

alter table #tab_CES_CORORATIVO_RET_AMP
add UN_CLUSTER varchar(50)

update #tab_CES_CORORATIVO_RET_AMP
set UN_CLUSTER = 'Cl�ster Retail Ampliado'
where UN_CLUSTER is null

drop table #tab_CES_CORORATIVO_RET_AMP_FINAL
select Periodo, UN_CLUSTER, CES_CORPORATIVO_FINAL_RET_AMP as CES 
into #tab_CES_CORORATIVO_RET_AMP_FINAL
from #tab_CES_CORORATIVO_RET_AMP

select * from #tab_CES_CORORATIVO_RET_AMP_FINAL





drop table #tab_consolidacion_CES
select *
into #tab_consolidacion_CES
from

(

select * from #tab_CES_PROCESAMIENTO_FINAL

union all

select * from #tab_CES_CORORATIVO_SERV_EXP_FINAL

union all

select * from #tab_CES_CORORATIVO_SERV_DIG_FINAL

union all

select * from #tab_CES_CORORATIVO_GOB_FINAL

union all

select * from #tab_CES_CORORATIVO_RET_AMP_FINAL

) as subquery








-- UNION A LA TABLA DE METRICAS DE EXP.



	-- tablas iniciales: 

	--select * from #tab_consolidacion_NPS
	--select * from #tab_consolidacion_SOL
	--select * from #tab_consolidacion_CES
	--select * from gdc..tbl_MET_EXP_final





alter table #tab_consolidacion_CES
add CSAT float


drop table #tab_consolidaciones_CES_SAT_NPS
select a.*, b.NPS
into #tab_consolidaciones_CES_SAT_NPS
from #tab_consolidacion_CES as a
left join #tab_consolidacion_NPS as b on a.Periodo = b.Periodo and a.UN_CLUSTER = b.UN_CLUSTER


drop table #tab_consolidaciones_CES_SAT_NPS_SOL
select a.*, b.SOL
into #tab_consolidaciones_CES_SAT_NPS_SOL
from #tab_consolidaciones_CES_SAT_NPS as a
left join #tab_consolidacion_SOL as b on a.Periodo = b.periodo and a.UN_CLUSTER = b.UN_CLUSTER
 


select * from #tab_consolidaciones_CES_SAT_NPS_SOL


		--insert into #tab_consolidaciones_CES_SAT_NPS_SOL 
		--	   (Periodo, UN_CLUSTER, CES, CSAT, NPS, SOL)
		--values (202208, 'UN Procesamiento', 0, 0, 1, 0.8571)


	

-- SE CORRE POR SEPRADO




insert into #tab_consolidaciones_CES_SAT_NPS_SOL (Periodo, UN_CLUSTER, CES, CSAT, NPS, SOL)
values (202208, 'Niubiz', 0.66, 0, 0.72, 0.91)

insert into #tab_consolidaciones_CES_SAT_NPS_SOL (Periodo, UN_CLUSTER, CES, CSAT, NPS, SOL)
values (202208, 'UN Masivo', 0.91, 0, 0.70, 0.66)

insert into #tab_consolidaciones_CES_SAT_NPS_SOL (Periodo, UN_CLUSTER, CES, CSAT, NPS, SOL)
values (202208, 'UN Corporativo', 0.67, 0, 0.77, 0.90)






-- agregar columna de Q_Encuestas y agregando el Q de Encuestas (excluir NEL y reemplazar por el total NEL ponderaci�n = 91)

alter table #tab_consolidaciones_CES_SAT_NPS_SOL
add Q_ENCUESTAS float


select * from #tab_consolidaciones_CES_SAT_NPS_SOL



update #tab_consolidaciones_CES_SAT_NPS_SOL
set q_encuestas = 3760
where UN_CLUSTER = 'UN Corporativo'
and Periodo = 202208


-- q_encuestas + q_encuesta_nel
select * from #tab_NPS_CORPORATIVO_SERV_EXP
select * from #tab_NPS_CORPORATIVO_SERV_DIG
select * from #tab_NPS_CORPORATIVO_GOB
select * from #tab_NPS_CORPORATIVO_RET_AMP
-- q_encuestas
select * from #tab_NPS_PROCESAMIENTO

		-- ponderacion NEL:

		--gob23 -> Cl�ster GED
		--dig21 -> Cl�ster Servicios Digitales
		--exp11 -> Cl�ster Servicios de Experiencia
		--ret36 -> Cl�ster Retail Ampliado






-- Paso Final: insertar todo en la tabla final de m�tricas de experiencia


select * from #tab_consolidaciones_CES_SAT_NPS_SOL

select * from gdc..tbl_MET_EXP_final

insert into gdc..tbl_MET_EXP_final
select *
from #tab_consolidaciones_CES_SAT_NPS_SOL
