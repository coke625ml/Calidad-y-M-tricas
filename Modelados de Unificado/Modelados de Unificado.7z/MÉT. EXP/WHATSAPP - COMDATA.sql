select *
from gdc..tbl_whatsapp_CP_inicial


-- 1. crear periodo

use [Visanet Planeamiento]

declare @Mes bigint
set @Mes = (select MAX(MONTH(Fecha)) from gdc..tbl_whatsapp_CP_inicial)

drop table #tab1
select a.*,
       MONTH(Fecha) as Mes,
	   YEAR(Fecha) as A�o
into #tab1
from gdc..tbl_whatsapp_CP_inicial as a
where MONTH(Fecha) = @Mes


drop table #tab2
select a.*,
       case when cast(Mes as float) <= 9 then cast(A�o as varchar) + '0' + cast(Mes as varchar)
	   else cast(A�o as varchar) + cast(Mes as varchar)
	   end as Periodo
into #tab2
from #tab1 as a

-- 2. Cruzar con UN, Segmento, Cluster, GV

drop table #tab3
select a.*,
       b.unidadnegocio,
	   b.Segmento,
	   b.ClusterGrupo
into #tab3
from #tab2 as a
left join V_Segmento_Cliente as b on a.DNI_RUC = b.Ruc


drop table #tab4
select a.*,
       b.Cuadrante_No_Aislado as Grupo_Valor_F
into #tab4
from #tab3 as a
left join gdc..tbl_GV as b on a.DNI_RUC = b.Ruc


-- select * from #tab4

-- 3. depuracion de SAT, SOL

drop table #tab5
select a.*,
       case when cast(substring(cast(SAT as varchar),1,1) as float) = 5 then  5
	        when cast(substring(cast(SAT as varchar),1,1) as float) = 1 then  1
	   else cast(SAT as float)
	   end as SAT_1,
	   case when SOL = 'S�' then 1
	   else 0
	   end as SOL_1,
	   case when cast(substring(cast(CES as varchar),1,1) as float) = 5 then  5
	        when cast(substring(cast(CES as varchar),1,1) as float) = 1 then  1
	   else cast(CES as float)
	   end as CES_1
into #tab5
from #tab4 as a


-- 3. Insertar en tabla final

insert into gdc..tbl_whatsapp_CP_final
select *
from #tab5
