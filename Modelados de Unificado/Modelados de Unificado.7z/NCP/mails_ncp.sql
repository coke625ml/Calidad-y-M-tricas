--delete from ncp_mails_inicial where periodo=202212
--select max(fecha) from ncp_mails_inicial periodo=12
--select count(*) from ncp_mails_inicial where periodo=202212

drop table #tab1
select a.*,
       case when [Tiempo rpta]<24 then 1
       else 0
       end as Dentro_SLA
into #tab1
from gdc..ncp_mails_inicial as a


drop table gdc..ncp_mails
select *
into gdc..ncp_mails
from #tab1


--select count(*) from gdc..ncp_mails where periodo=202212
--select max(periodo) from gdc..ncp_mails


