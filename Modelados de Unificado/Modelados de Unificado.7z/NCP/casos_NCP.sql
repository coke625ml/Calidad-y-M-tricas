--delete from ncp_mails_inicial where month(fecha)=11
--select max(fecha) from ncp_mails_inicial where month(fecha)=11
--select count(*) from ncp_mails_inicial where month(fecha)=11

drop table #tab1
select a.*,
       case when cast(Segmento as varchar) = 'Clientes Estrat�gicos' and cast([Tiempo rpta] as float) < 1.5 and cast(Periodo as float) >= 202206 then 1
            when cast(Segmento as varchar) = 'Corporativo' and cast([Tiempo rpta] as float) < 6 and cast(Periodo as float) >= 202206 then 1
            when cast(Segmento as varchar) = 'Masivo' and cast([Tiempo rpta] as float) < 24 and cast(Periodo as float) >= 202206 then 1
			when cast(Segmento as varchar) in ('Ultra TOP' ,'Clientes Estrat�gicos')and cast([Tiempo rpta] as float) < 1.5 and cast(Periodo as float) <=202205 and cast(Periodo as float) > =202204 then 1
			when cast(Segmento as varchar) = 'Corporativo' and cast([Tiempo rpta] as float) < 6and cast(Periodo as float) < =202205 and cast(Periodo as float) >= 202204 then 1
			when cast(Segmento as varchar) not in ( 'Corporativo','Ultra TOP','Clientes Estrat�gicos') and cast([Tiempo rpta] as float) < 24 and cast(Periodo as float) <= 202205 and cast(Periodo as float) > =202204 then 1
			when cast(Segmento as varchar) in ( 'ULTRA VIP','Ultra TOP') and cast([Tiempo rpta] as float) < 1.5  and cast(Periodo as float) <= 202203 and cast(Periodo as float) > =202201 then 1
			when cast(Segmento as varchar) = 'TOP Corporativo' and cast([Tiempo rpta] as float) < 3 and cast(Periodo as float) <= 202203 and cast(Periodo as float) > =202201 then 1
			when cast(Segmento as varchar) not in ( 'TOP Corporativo','Ultra TOP','ULTRA VIP') and cast([Tiempo rpta] as float) < 12 and cast(Periodo as float) <= 202203 and cast(Periodo as float) > =202201 then 1

       else 0
       end as Dentro_SLA
into #tab1
from gdc..ncp_mails_inicial as a


drop table gdc..ncp_mails
select *
into gdc..ncp_mails
from #tab1


--select * from gdc..ncp_mails where Periodo=202210
--select max(periodo) from gdc..ncp_mails


